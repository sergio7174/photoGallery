export class User {
  constructor(
    firstname: String,
    lastname: String,
    username: String,
    email: String,
    password: String,
    gender: String
  ) {}
}
