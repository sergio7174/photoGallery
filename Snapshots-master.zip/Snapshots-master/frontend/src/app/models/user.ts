export class User {
  firstname: String;
  lastname: String;
  username: String;
  password: String;
  email: String;
}
