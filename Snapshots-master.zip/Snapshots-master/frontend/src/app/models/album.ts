export class Album {
  title: String;
  description: String;
  privacy: String;
}
