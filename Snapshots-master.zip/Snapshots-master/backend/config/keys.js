module.exports = {
  mongoURI: "mongodb://alfur:alfur123@ds349455.mlab.com:49455/photoapp",
  secretOrKey: "secret123"
};
//mongodb://<dbuser>:<dbpassword>@ds349455.mlab.com:49455/photoapp
